"""PAC Core Package."""
